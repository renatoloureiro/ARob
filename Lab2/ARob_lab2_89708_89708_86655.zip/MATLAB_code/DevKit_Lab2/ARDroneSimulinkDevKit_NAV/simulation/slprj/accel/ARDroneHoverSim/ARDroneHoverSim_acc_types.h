#include "__cf_ARDroneHoverSim.h"
#ifndef RTW_HEADER_ARDroneHoverSim_acc_types_h_
#define RTW_HEADER_ARDroneHoverSim_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct P_ARDroneHoverSim_T_ P_ARDroneHoverSim_T ;
#endif
